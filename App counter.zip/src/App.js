import { useState } from "react"
import './App.css'

export default function App() {
        const [count, setCount] = useState(0)
    
        function add() {
            setCount(count + 1)
        }
        
        return (
            <div className="container">
                <div className="counter">
                    <div className="counter--count">
                        <h1>{count}</h1>
                        <a href="#" className="counter--plus" onClick={add}>Click to increase counter</a>
                    </div>
                </div>
                <button className="change-color">Change Color</button>
            </div>
        )
}