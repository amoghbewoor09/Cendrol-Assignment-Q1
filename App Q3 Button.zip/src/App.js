import { useState } from "react"
// import './App.css'

export default function App() {

    const [isTrue, setIsTrue] = useState(false);

const handleClick = () => {
  setIsTrue(!isTrue);
};

return (
  <button 
    style={{backgroundColor: isTrue ? 'red' : 'blue'}}
    onClick={handleClick}
  >
    Toggle Color
  </button>
);
}