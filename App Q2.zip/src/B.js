function B(props) {
        const increment = () => {
              props.setCendol((val) => val + 10)
              console.log(props.cendol)
        }
  
        return (
              <div>
                    <h1>Value: {props.cendol}</h1>
                    <button onClick={increment}>Click to Increment!</button>
              </div>
        );
  }
  
  export default B;