import { useState } from "react"
import B from "./B"

export default function App() {
        const [cendol, setCendol] = useState(2);
    return(
        <div>
        <B cendol={cendol} setCendol={setCendol}></B>
        </div>
    )
}